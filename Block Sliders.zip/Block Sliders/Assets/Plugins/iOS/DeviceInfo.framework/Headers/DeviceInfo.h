#import <Foundation/Foundation.h>

extern "C" {
  const char * _GetCFBundleID();
  const bool _GetNoTrackFlag();
}